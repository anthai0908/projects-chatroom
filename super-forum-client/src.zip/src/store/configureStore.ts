import {configureStore} from "@reduxjs/toolkit";
import { rootReducer } from "./AppState";

const  store = configureStore({
    reducer : rootReducer,
});
export default store;