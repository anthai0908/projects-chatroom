export default class CategoryThread{
    constructor(public threadID: string,
                public categoryName: string,
                public title: string,    
    ){}
}